def handler(event, context):
    print('Hello World')